package Fixtures;

import control.OperatorContoller;
import fit.ActionFixture;

public class newAppointmentCreating extends ActionFixture {
	boolean expected;
	
	public boolean isExpected() {
		return expected;
	}
	
	public void checkPatientID(int patientID) {
		try {
			expected = OperatorContoller.checkPatientID(patientID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void referralIDsearch(int id){
		try {
			expected =  OperatorContoller.referralIDsearch(null, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
