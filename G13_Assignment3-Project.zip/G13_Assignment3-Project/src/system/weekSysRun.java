package system;

public class weekSysRun implements Runnable {

	
	@Override
	public void run() {
	}

}
