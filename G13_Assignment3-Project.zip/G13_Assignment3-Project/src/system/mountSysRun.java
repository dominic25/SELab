package system;

public class mountSysRun implements Runnable {

	@Override
	public void run() {
	}

}
