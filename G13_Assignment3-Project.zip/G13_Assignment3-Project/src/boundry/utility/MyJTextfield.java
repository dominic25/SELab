package boundry.utility;

import javax.swing.JTextField;

public class MyJTextfield extends JTextField implements UtilltyGUI {

	private static final long serialVersionUID = 3282355125263831663L;

}
