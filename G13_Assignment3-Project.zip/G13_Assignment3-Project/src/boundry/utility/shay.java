package boundry.utility;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Random;
import java.util.TimeZone;

import javax.sql.rowset.CachedRowSet;
import javax.swing.JOptionPane;
import javax.swing.Timer;

import ocsf.Main.MainClient;
import boundry.GUI.ClinicManegerGUI;
import boundry.GUI.NewPatientGUI;
import boundry.GUI.OperatorAddAppointmentGUI;
import boundry.GUI.OperatorMainGUI;
import boundry.GUI.OperatorMenuGUI;
import email.EmailController;
import entity.Patient;
import entity.User;



public class shay {

	
	public static void main(String []args) throws Exception{
		
		//new ClinicManegerGUI(3001);
		
		
		//new CalendarProgram(2);
	//new OperatorMainGUI();
		//new NewPatientGUI();
		//new OperatorMenuGUI(null);
		//new OperatorAddAppointmentGUI(null,"kard");
		//JOptionPane.showMessageDialog(null,"Message Confirmation About Cancel  Appointment\n"+"Send an email to the customer");//Display message for operator.
		//EmailController.sendEmail("shayzaf25@gmail.com","Confirmation About Cancel  Appointment", "Appointment number"+ 14 +"canceled");
//			Calendar cal = Calendar.getInstance();
//				System.out.println(cal.getTime());
//		java.util.Date date =  cal.getTime();
//		System.out.println (date.getHours());
//		System.out.println (date.getMinutes());
//		date.setHours(8);
//		date.setTime(time);
//		System.out.println(date.getHours());
//	      SimpleDateFormat ft = 
//	    	      new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
//                
		//Calendar cal=Calendar.getInstance();
		//TimeZone date=cal.getTimeZone();
//		GregorianCalendar cal = new GregorianCalendar();
//		//Date date=cal.getTime();
//		 realDay = cal.get(GregorianCalendar.DAY_OF_MONTH);
//		System.out.println("\n date of today is  "+ cal.get);
//	   
		

		
		

		
		


		
		
	     
//	       LocalDate today=LocalDate.now();
//                  today.atStartOfDay();
//	    	      System.out.println("Current Date: " + ft.format(date));
//	    	      System.out.println("time now is " +date.getHours());
//	    	    
//	    	      int delay = 0;
//	    	      Timer timer = new Timer()
//	Timer timer = new Timer(delay, new ActionListener() {
//	    	    	    @Override
//	    	    	    public void actionPerformed(ActionEvent e) {
//	    	    	        // Timer Action
//	    	    	    }
//	    	    	});
//	    	    	timer.start();
//	    	    	timer.
		
	}
	
	
}
