package boundry.GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.sql.rowset.CachedRowSet;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import ocsf.Main.MainClient;
import email.EmailController;
import entity.Patient;
import boundry.utility.MyJPanel;
/**
 * 
 * @author shay zafran
 *
 */
public class NewPatientGUI extends AbstractGUI {

	
	private static final long serialVersionUID = 1L;
	private JTextField patientID;
	private JTextField f_name;
	private JTextField l_name;
	private JTextField email;
	private JButton save;
	private Patient patient;
	private MyJPanel gPanel;
	private static final String[] gtexts = {"Patient ID", "Name", "Family Name", "Email", "Address","Gender","HMO Name","Height"};
	
	/**
	 * NewPatientGUI constructor,without parameters,defining buttons
	 * Insert details of patient to abstract_person table
	 * Chose the worker_num with random method
	 * Insert details of patient to person table
	 */
	public NewPatientGUI() {
		
		setTitle("New Patient");
            
		
		gPanel=new MyJPanel(gtexts, 0, 0, frameWidth, 100);
		gPanel.setSize(1366, 204);
		gPanel.setLocation(0, 0);
		getContentPane().add(gPanel);
		
		//Define save button.
		save = new JButton("Save");
		save.setFont(bigText);
		save.setBounds(442, 323, 200, 70);
		getContentPane().add(save);
		
		ArrayList<JTextField> gOrder = gPanel.getgOrder();
		
		
		save.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				
				ArrayList<Integer> arr ;
				int i=0;
				int id=Integer.parseInt(gOrder.get(0).getText());
				double height=Double.parseDouble(gOrder.get(7).getText());
				
				System.out.println(" the id:"+ id+"\nName: "+gOrder.get(1).getText()+"last:"+gOrder.get(2).getText()+"email:"+ gOrder.get(3).getText()+"addrss:"+gOrder.get(4).getText()+" gender: "+gOrder.get(5).getText());
				
				//Insert details of patient to abstract_person table.
				String msg="INSERT INTO abstract_person VALUES("+id+",'" +gOrder.get(1).getText()+"','" +gOrder.get(2).getText()+"','"+gOrder.get(3).getText()+"','"+ gOrder.get(4).getText()+"','"+ gOrder.get(5).getText()+"')"; 

				String msg1="SELECT worker_num FROM user where role='doctor'";
				
				try {	
					
					MainClient.mainClient.sendToServer(msg);
					arr = new ArrayList<Integer>();
					CachedRowSet row =(CachedRowSet)MainClient.mainClient.sendAndWaitForReply(msg1);
					while(row.next()){
						arr.add(row.getInt(1));
						i++;	
					}
					//Chose the worker_num with random method.
					Random rnd = new Random();
					int index = 0 + rnd.nextInt(arr.size());
					int worker_num=arr.get(index);
					
					for(int j=0;j<arr.size();j++)
					{
						System.out.println(j+"."+arr.get(j)+"\n");
					}
					//System.out.println("the index:"+ index+"\nthe random worker num:"+ worker_num);

					//Insert details of patient to person table.
					String msg2="INSERT INTO patient VALUES("+id+","+worker_num+",'"+gOrder.get(6).getText()+"',"+height+")";
					MainClient.mainClient.sendToServer(msg2);
					JOptionPane.showMessageDialog(getContentPane(),"New Patient was added to the Data Base");
					EmailController.sendEmail(gOrder.get(3).getText(), "Welcome to Ihealth","Hellow "+ gOrder.get(1).getText()+"\n and welcome to our service.");
					setVisible(false);
					new OperatorMainGUI();
                    
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
	
			}

		});
		
		
		
		//Presses backward button//
		backward.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new OperatorMainGUI();
				//dispose();
			}});
		
		
		forward.setVisible(false);
		setVisible(true);
		

	}//Constructor NewPatientGUI().
	
		

}