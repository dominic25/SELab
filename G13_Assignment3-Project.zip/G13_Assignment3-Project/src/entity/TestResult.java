package entity;

public class TestResult {

	private int referralID;
	private String Description;
	private int Image;

	/**
	 * getDescription
	 * @return Description
	 */
	public String getDescription() {
		// TODO - implement TestResult.getDescription
		throw new UnsupportedOperationException();
	}

	/**
	 * setDescription
	 * @param Description
	 */
	public void setDescription(int Description) {
		// TODO - implement TestResult.setDescription
		throw new UnsupportedOperationException();
	}
/**
 * getImage
 * 
 */
	public void getImage() {
		// TODO - implement TestResult.getImage
		throw new UnsupportedOperationException();
	}

	/**
	 * setImage
	 * @param Image
	 */
	public void setImage(int Image) {
		// TODO - implement TestResult.setImage
		throw new UnsupportedOperationException();
	}
/**
 * TestResult constructor
 */
	public TestResult() {
		// TODO - implement TestResult.TestResult
		throw new UnsupportedOperationException();
	}

}