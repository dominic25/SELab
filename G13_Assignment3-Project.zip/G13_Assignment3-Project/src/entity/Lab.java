package entity;

public class Lab {

}
