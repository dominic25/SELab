package entity;

public class Clinic {

	private int ClinicID;
	private String ClinicName;
	private String[] WorkersArray;
	private int numOfPatients;
	private String[] patientsID;
	private String managerID;
	private Lab lab;
	private static Clinic clinic;

	/**
	 * getClinicID
	 * @return ClinicID
	 */
	public String getClinicID() {
		// TODO - implement Clinic.getClinicID
		throw new UnsupportedOperationException();
	}

	/**
	 * setClinicID
	 * @param ClinicID
	 */
	public void setClinicID(String ClinicID) {
		// TODO - implement Clinic.setClinicID
		throw new UnsupportedOperationException();
	}

	/**
	 * getNumOfPatients
	 * @return numOfPatients
	 */
	public int getNumOfPatients() {
		return this.numOfPatients;
	}

	/**
	 * setNumOfPatients
	 * @param numOfPatients that is equals to this.numOfPatients 
	 */
	public void setNumOfPatients(int numOfPatients) {
		this.numOfPatients = numOfPatients;
	}

	/**
	 * getPatientsID
	 * @return patientsID
	 */
	public String[] getPatientsID() {
		return this.patientsID;
	}

	/**
	 * setPatientsID
	 * @param patientsID that is equals to this.patientsID
	 */
	public void setPatientsID(String[] patientsID) {
		this.patientsID = patientsID;
	}

	/**
	 * getClinicName
	 * @return ClinicName
	 */
	public String getClinicName() {
		// TODO - implement Clinic.getClinicName
		throw new UnsupportedOperationException();
	}

	/**
	 * setClinicName
	 * @param clinicname
	 */
	public void setClinicName(String clinicname) {
		// TODO - implement Clinic.setClinicName
		throw new UnsupportedOperationException();
	}
/**
 * getDoctorName
 * @return DoctorName
 */
	public  String getDoctorName() {
		// TODO - implement Clinic.getDoctorName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param clinicID
	 */
	public Clinic(int clinicID) {
		// TODO - implement Clinic.Clinic
		throw new UnsupportedOperationException();
	}

}