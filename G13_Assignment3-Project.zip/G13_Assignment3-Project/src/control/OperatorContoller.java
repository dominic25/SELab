package control;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.sql.rowset.CachedRowSet;
import javax.swing.JOptionPane;

import com.mysql.jdbc.Statement;

import ocsf.Main.MainClient;
import email.EmailController;
import entity.Patient;

/**
 * 
 * @author shay zafran
 *
 */

public class OperatorContoller {
   
   
	/**
	 * 
	 * @param patient
	 * @param appointmentRefferal
	 */


	/**
	 * cancelAppointment method that canceling an appointment to the patient by the operator
	 * @param apcID 
	 */
		public static void cancelAppointment(int apcID,String email,int id) {
		boolean result=false;
		Calendar cal=Calendar.getInstance();
		Date date=cal.getTime();
		String msg="delete from operator_appointment_creation where apcID="+apcID;
		 try {
             String message="select apcID from operator_appointment_creation where patientID="+id;
             CachedRowSet row =(CachedRowSet)MainClient.mainClient.sendAndWaitForReply(message);
             while(row.next()){
            	 System.out.println("(opc11) apcID "+ row.getInt(1));
            	if(row.getInt(1)==apcID)result=true;//check if  appointment number belong to the patient and exist in DB.  
             }
             if(result){//If true->Delete from DB,else don't do nothing.
			MainClient.mainClient.sendToServer(msg);
			JOptionPane.showMessageDialog(null,"Message Confirmation About Cancel  Appointment\n"+"Send an email to the customer");//Display message for operator.	
			//EmailController.sendEmail(email,"Confirmation About Cancel  Appointment", "Appointment number "+ apcID +" canceled");
             }
             else JOptionPane.showMessageDialog(null,"The desire appointment id doesn't exist in data base!");//Display message for operator.	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("the message is:"+msg);
		
		
	}

	/**
	 * check if the patient exist in DB.
	 * @param patientID parameter that by him we check if patient is exist in db
	 * @throws Exception 
	 */
	public static boolean checkPatientID(int patientID) throws Exception {
		// TODO - implement OperatorContoller.checkPatientID
		String str=null;
	
		str ="SELECT personID FROM patient WHERE personID="+patientID;

			CachedRowSet row = (CachedRowSet)MainClient.mainClient.sendAndWaitForReply(str);
			if(row.next()){
			//int n=row.getInt(1);
			
			System.out.println("(main)patient ID is="+row.getInt(1));
			if(patientID==row.getInt(1))
			{
				System.out.println("Found");
				return true;
			}
		}//End if
			return false;
		
	}//End method checkPatientID.


	/**
	 * referralIDsearch is searching referral id in db
	 * @param str
	 * @param id of referral
	 * @return boolean
	 * @throws Exception
	 */
	public static boolean referralIDsearch(String str,int id) throws Exception{
		//ArrayList<Integer> element=new ArrayList<>();
		
		
		String str1=null;
		int i=0;

	//	System.out.println("(operator con)the id is:"+id);
		//System.out.println("(operator con)the query is:"+str);
		//str1="SELECT ReferralID,Status FROM abstract_referral WHERE refPatientID="+id;
	    str1="SELECT ReferralID FROM abstract_referral WHERE refPatientID="+id+" and Status=0 and ReferralId in(select ReferralNum from referral where doc_specialization='"+str+"')";

	    CachedRowSet row = (CachedRowSet)MainClient.mainClient.sendAndWaitForReply(str1);
	   
	    if(row.next())return true;
		return false;
	   
	
	
	    
	}		    	
	
	/**
	 * getReferralid gives the referral id
	 * @param id ,for the id referral
	 * @return id of the referral
	 */
	public static int getReferralid(int id){
		return id;
	}
}