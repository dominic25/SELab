package control;

public class ManegerContoller {

	/**
	 * 
	 * @param manegerID
	 */
	public void WeekBasisReports(String manegerID) {
		// TODO - implement ManegerContoller.WeekBasisReports
		throw new UnsupportedOperationException();
	}

	public void MonthBasisReports() {
		// TODO - implement ManegerContoller.MonthBasisReports
		throw new UnsupportedOperationException();
	}

}