package control;

import java.awt.Color;
import java.awt.Font;
import javax.sql.rowset.CachedRowSet;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import control.LaboratorianController;
import entity.TestReferral;
import javax.swing.border.BevelBorder;
import ocsf.Main.MainClient;
import boundry.GUI.*;
/**
 * 
 * @author Vlad Teplitski
 *
 */
public class LaboratorianController extends AbstractMenuGUI{

	private static final long serialVersionUID = 1L;
	public static JButton hideRefBtn;
	public static JPanel panel_1;

	/**
	 * checkReferral method that checks referralnum in database
	 * @param ref 
	 * @return
	 * @throws Exception
	 */
	
	public static boolean checkReferral(int ref) throws Exception  //check if referral exists
	{
		String str=null; //SQL string
		
		str ="SELECT testReferralNum FROM test_referral WHERE testReferralNum="+ref; //SQL Query
		//connect to DB server
		CachedRowSet row = (CachedRowSet)MainClient.mainClient.sendAndWaitForReply(str);

		if(row.first()==false)  // check if there is no data - not found in DB
			return false;
		
        return true;
	}
	/**
	 * Show_referral_for_medical_examinations 
	 * @param testReferral
	 * @param textarea1 -Test information
	 * @param panel_1
	 * @throws Exception
	 */
	
	public static void Show_referral_for_medical_examinations(TestReferral testReferral,JTextArea textarea1,JPanel panel_1) throws Exception {
		
		//status indication
		String str_status=null;
		if(testReferral.Status)
			str_status="closed";
		else
			str_status="open";   //if 0
		//end status indication
		
		panel_1 = new JPanel();
		panel_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_1.setBackground(new Color(204, 204, 255));
		panel_1.setBounds(908, 140, 418, 211);
		
		
		textarea1.setToolTipText("Test information");
		textarea1.setBackground(panelColor);
		textarea1.setTabSize(20);
		textarea1.setAlignmentX(LEFT_ALIGNMENT);
		textarea1.setAlignmentY(CENTER_ALIGNMENT);
		textarea1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		
		textarea1.setText(
		"Referral Details for medical examination:"+"\nPatient ID:  "+testReferral.patient_id
												   +"\nDate:  "+testReferral.date
												   +"\nStatus:  "+str_status
												   +"\nTest Description:  "+testReferral.description
												   +"\nTest Kind:  "+testReferral.Test_Kind);
		                                          
	
	}
	
	/**
	 * Insert_Test_Result method insert test results
	 * @param testReferral
	 * @throws Exception
	 */
	public static void Insert_Test_Result(TestReferral testReferral) throws Exception {
		
		new insertLabTestResultsGUI(testReferral);   //GUI of lab results insert
	}


	/**
	 * CloseRefferal method -we sign 1 after taking care of referral and close it
	 * @param testReferral
	 * connection with database 
	 */
	public static void CloseRefferal(TestReferral testReferral) {
		
		
		String status_string = "UPDATE abstract_referral SET `status` = 1 WHERE `ReferralID`="+testReferral.ReferralID;
	
						
		//connect to DB server
		try {

		MainClient.mainClient.sendToServer(status_string);

		
		} catch (Exception e) {
			e.printStackTrace();}

	}
	
}