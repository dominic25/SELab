package control;

import entity.Patient;

public class SearcherController {

	/**
	 * clinicSearch method
	 * @param doctorSpetiallty
	 */
	public static String clinicSearch(String doctorSpetiallty) {
		// TODO - implement SearcherController.clinicSearch
		throw new UnsupportedOperationException();
	}

	/**
	 * dateChoose method
	 * @param doctorName
	 * @param clinicName
	 */
	public static void dateChoose(String doctorName, String clinicName) {
		// TODO - implement SearcherController.dateChoose
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param date
	 */
	public static void registerDate(String date) {
		// TODO - implement SearcherController.registerDate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param patient
	 * @param refferalID
	 */
	public static String createConfirmationDateGui(Patient patient, String refferalID) {
		// TODO - implement SearcherController.createConfirmationDateGui
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param doctorSpetiallty
	 */
	public static void checkDoctorSpeciality(String doctorSpetiallty) {
		// TODO - implement SearcherController.checkDoctorSpeciality
		throw new UnsupportedOperationException();
	}

}